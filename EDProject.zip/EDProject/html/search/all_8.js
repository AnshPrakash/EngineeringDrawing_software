var searchData=
[
  ['scale_5fobject',['Scale_object',['../class_transformation.html#aebf34960b29b172183ea71cf31402581',1,'Transformation']]]
];
