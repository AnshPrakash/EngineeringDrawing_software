var searchData=
[
  ['requesthandler',['RequestHandler',['../class_request_handler.html#a5f47febd4b90dd6fc49b1f8303247c69',1,'RequestHandler']]],
  ['rotationx',['RotationX',['../class_transformation.html#aee6723b5b6515bd81a227f18ff6e5180',1,'Transformation']]],
  ['rotationy',['RotationY',['../class_transformation.html#aaa309d337dbe21d4b47148586c2525f4',1,'Transformation']]],
  ['rotationz',['RotationZ',['../class_transformation.html#a67536ea8c7e1c1c10c5810cbabe36a37',1,'Transformation']]]
];
