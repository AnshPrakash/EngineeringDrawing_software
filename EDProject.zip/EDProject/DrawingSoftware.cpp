#include <iostream>
#include <list>
#include <tuple>
// #include <windows>

/**
 *	A Node object contains its own co-ordinate.
 * 	Neighbours List
 *
 */
class Node{
	public:
	float x;
	float y;
	float z;
	std::list<Node*> Neighbours;
	/**
	 *@return std::tuple<float,flaot,float>
	 *Gives the Locayion of the Point.
	 *	
	 */
	std::tuple<float,float,float>  getLocation(){
		return std::make_tuple(x,y,z);
	}
	/**
	 *Gives the List of points connected to this point.
	 *
	 *
	 */
	std::list<Node*> getNeighbours(){
		return Neighbours;
	}

};
/**
 * 
 * This is the Graph which contains all the Node with there connections.
 * 
 * 
 */
class Graph{
	std::list<Node*> All_Node;/*!< It is the Graph */
	void CreateGraph(){
	}
};
/**
 *
 * Contains the functions to give the 2D graph to form an Image.
 *
 *
 */
class Projection
{
public:
	Projection();
	~Projection();
	/**
	 * Give the projected Node on Profile View in a List.
	 * @param std::list<Node*>
	 *
	 */
	std::list<Node*> ProfileView(std::list<Node*> given_graph){

	}
	/**
	 * Give the projected Node on Front View in a List.
	 * @param std::list<Node*>
	 *
	 */
	std::list<Node*> FrontView(std::list<Node*> given_graph){

	}
	/**
	 * Give the projected Node on Top View in a List.
	 * @param std::list<Node*>
	 *
	 */
	std::list<Node*> TopView(std::list<Node*> given_graph){

	}
};
/**
 * Create 2D and 3D Image
 * 
 *
 */
class CreateImage
{
public:
	CreateImage();
	~CreateImage();
	/**
	 *It Displays the Image of the object in the Front View
	 *@param std::list<Node*>
	 *	
	 */
	void CreateFrontView(std::list<Node*> plane){

	}
	/**
	 *It Displays the Image of the object in the Top View
	 *@param std::list<Node*>
	 *	
	 */
	void CreateTopView(std::list<Node*> plane){

	}
	/**
	 *It Displays the Image of the object in the Profile View
	 *@param std::list<Node*>
	 *	
	 */
	void CreateProfileView(std::list<Node*> plane){

	}
	/**
	 *It Displays the  Image of the object in the 3D View
	 *@param std::list<Node*>
	 *	
	 */
	void Create3DView(std::list<Node*> graph){

	}
};
/**
 *
 *It takes the input from the user and write it a the file
 *
 *
 */
class RequestHandler
{
public:
	RequestHandler();
	~RequestHandler();
};
/**
 * Return a graph after doing transformation with original graph
 *
 *
 */
class Transformation
{
public:
	Transformation();
	~Transformation();
	/**
	 *return's a graph after Rotaion about X-axis of each point.
	 *@param float theta
	 *@return std::list<Node*>
	 */
	std::list<Node*> RotationX(float theta){

	}
	/**
	 *return's a graph after Rotaion about Y-axis of each point.
	 *@param float theta
	 *@return std::list<Node*>
	 */
	std::list<Node*> RotationY(float theta){

	}
	/**
	 *return's a graph after Rotaion about Z-axis of each point.
	 *@param float theta
	 *@return std::list<Node*>
	 */
	std::list<Node*> RotationZ(float theta){

	}
	/**
	 *return's a graph after scaaling each point in the graph
	 *@param float theta
	 *@return std::list<Node*>
	 */
	std::list<Node*> Scale_object(float theta){

	}
};
int  main(){
 	/**
 	 * This part will mainly contains gui program
 	 */
	return 0;
}