var searchData=
[
  ['x',['x',['../class_node.html#a3a6b88b82c51d21305656d01e3c53039',1,'Node::x()'],['../_product_8cpp.html#afadc88aa497af3b0e7b1af9369375b64',1,'X():&#160;Product.cpp']]]
];
