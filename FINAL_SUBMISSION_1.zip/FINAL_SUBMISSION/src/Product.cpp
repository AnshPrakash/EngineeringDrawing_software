#include <iostream>
#include <tuple>
#include <vector>
#include <fstream>
#include <string>
#include <sstream>
#include <map>
#include <GL/glut.h>
using namespace std;


GLfloat X = 0.0f; // Translate screen to x direction (left or right)
GLfloat Y = 0.0f; // Translate screen to y direction (up or down)
GLfloat Z = 0.0f; // Translate screen to z direction (zoom in or out)
GLfloat rotX = 0.0f; // Rotate screen on x axis 
GLfloat rotY = 0.0f; // Rotate screen on y axis
GLfloat rotZ = 0.0f; // Rotate screen on z axis
GLfloat rotLx = 0.0f; // Translate screen by using the glulookAt function (left or right)
GLfloat rotLy = 0.0f; // Translate screen by using the glulookAt function (up or down)
GLfloat rotLz = 0.0f; // Translate screen by using the glulookAt function (zoom in or out)


/**
 *	A Node object contains its own co-ordinate.
 * 	Neighbours List
 *
 */
class Node{
	public:
	float x;
	float y;
	float z;
	std::vector<Node*> Neighbours;
	/**
	 *@return std::tuple<float,flaot,float>
	 *Gives the Location of the Point.
	 *	
	 */
	std::tuple<float,float,float>  getLocation(){
		return std::make_tuple(x,y,z);
	}
	/**
	 *Gives the List of points connected to this point.
	 *
	 *
	 */
	std::vector<Node*> getNeighbours(){
		return Neighbours;
	}

};
std::vector<std::vector<Node*> > cyclesD;
std::vector<std::vector<std::vector<float>>> colorsRand;


/**
 * 
 * This is the Graph which contains all the Node with there connections.
 * 
 * 
 */
class Graph{
	public:
	std::vector<Node*> All_Node;/*!< It is the Graph */
	/**
	 * Give the projected Node on Profile View in a List.
	 * @param std::vector<Node*>
	 *
	 */
	std::vector<Node*> ProfileView(std::vector<Node*> given_graph){
		std::vector<Node*> v;
		for(int i=0;i<given_graph.size();i++){
			Node *n=new Node();
			std::vector<Node*> nei;
			Node *t=given_graph[i];
			n->x=t->y;
			n->y=t->z;
			n->z=0;
			nei=t->Neighbours;
			std::vector<Node*> new_nei;
			for(int j=0;j<nei.size();j++){
				Node *neibj=new Node();
				neibj->x=nei[j]->y;
				neibj->y=nei[j]->z;
				neibj->z=0.0;
				new_nei.push_back(neibj);
			}
			n->Neighbours=new_nei;
			v.push_back(n);
		}
		return v;
	}
	/**
	 * Give the projected Node on Front View in a List.
	 * @param std::vector<Node*>
	 *
	 */
	std::vector<Node*> FrontView(std::vector<Node*> given_graph){
		std::vector<Node*> v;
		for(int i=0;i<given_graph.size();i++){
			Node *n=new Node();
			std::vector<Node*> nei;
			Node *t=given_graph[i];
			n->x=t->x;
			n->y=t->y;
			n->z=0;
			nei=t->Neighbours;
			std::vector<Node*> new_nei;
			for(int j=0;j<nei.size();j++){
				Node *neibj=new Node();
				neibj->x=nei[j]->x;
				neibj->y=nei[j]->y;
				neibj->z=0;
				new_nei.push_back(neibj);
			}
			n->Neighbours=new_nei;
			v.push_back(n);
		}
		return v;
	}
	/**
	 * Give the projected Node on Top View in a List.
	 * @param std::vector<Node*>
	 *
	 */
	std::vector<Node*> TopView(std::vector<Node*> given_graph){
		std::vector<Node*> v;
		for(int i=0;i<given_graph.size();i++){
			Node *n=new Node();
			std::vector<Node*> nei;
			Node *t=given_graph[i];
			n->x=t->x;
			n->y=t->z;
			n->z=0;
			nei=t->Neighbours;
			std::vector<Node*> new_nei;
			for(int j=0;j<nei.size();j++){
				Node *neibj=new Node();
				neibj->x=nei[j]->x;
				neibj->y=nei[j]->z;
				neibj->z=0;
				new_nei.push_back(neibj);
			}
			n->Neighbours=new_nei;
			v.push_back(n);
		}
		return v;
	}
	std::vector<float> crossProduct(std::vector<float> vect_A, std::vector<float>  vect_B){
		std::vector<float> cross_P;	 
	    cross_P.push_back(vect_A[1] * vect_B[2] - vect_A[2] * vect_B[1]);
	    cross_P.push_back( vect_A[2] * vect_B[0]-vect_A[0] * vect_B[2] );
	    cross_P.push_back( vect_A[0] * vect_B[1] - vect_A[1] * vect_B[0]);
	    return cross_P;
	}
	//not working Incomplete
	/**
	 * Finds all the cycles of the graph.
	 * 
	 * @return std::map<Node*, Node*>
	 */
	std::map<Node*, Node*> find_cycle(std::vector<float> Eq,Node* n,Node* prev,std::map<Node*, Node*>& visited){
		std::vector<Node*> nei=n->Neighbours;
			// std::cout<<"Hello"<<"\n";
			// std::cout<<"prev"<<prev->x<<" "<<prev->y<<" "<<prev->z<<"\n";
			// std::cout<<n->x<<" "<<n->y<<" "<<n->z<<"\n";
		for(int i=0;i<nei.size();i++){
			// std::cout<<i<<"Hey  "<<nei[i]->x<<","<<nei[i]->y<<","<<nei[i]->z<<","<<"\n";
			float sum=Eq[0]*nei[i]->x +Eq[1]*nei[i]->y+Eq[2]*nei[i]->z -Eq[3];
			int s=static_cast<int>(sum);			
			if(s==0 && prev!=nei[i]){
				// cout<<"why  "<<s<<"\n";
				// cout<<visited.count(nei[i])<<"  haha\n";
				visited[n]=nei[i];
				if(visited.count(nei[i])>0){	
					// cout<<"returning\n";
					return visited;
				}
				find_cycle(Eq,nei[i],n,visited);
				// cout<<"got it\n";
				// std::cout<<n->x<<" "<<n->y<<" "<<n->z<<"\n";

				return visited;
			}
			// cout<<"hhihihi  i   "<<i<<endl;
		}
		// cout<<"I am here\n";
		std::map<Node*,Node*> empty;
		return empty;
	}
	/**
	 * Finds all the Planes of the figure.
	 * @param std::vector<Node*>
	 * @return std::vector<std::vector<Node*> >
	 */
	std::vector<std::vector<Node*> >  getPlanes(std::vector<Node*> graph){
		vector<vector<Node*>> v;
		std::map<Node*, Node*> cycle;
		for(int i=0;i<graph.size();i++){
			float x1,x2,x3;
			x1=graph[i]->x;
			x2=graph[i]->y;
			x3=graph[i]->z;
			
			for(int j=0;j<graph[i]->Neighbours.size();j++){
				float y1,y2,y3;
				y1=graph[i]->Neighbours[j]->x;
				y2=graph[i]->Neighbours[j]->y;
				y3=graph[i]->Neighbours[j]->z;
				
				for(int k=j+1;k<graph[i]->Neighbours.size();k++){
					float z1,z2,z3;
					z1=graph[i]->Neighbours[k]->x;
					z2=graph[i]->Neighbours[k]->y;
					z3=graph[i]->Neighbours[k]->z;
					// std::cout<<x1<<' '<<x2<<' '<<x3<<' ';
					// std::cout<<y1<<' '<<y2<<' '<<y3<<' ';
					// std::cout<<z1<<' '<<z2<<' '<<z3<<"\n\n";
					std::vector<float> t;
					std::vector<float> di;
					float d;
					t.push_back(x1-y1);
					t.push_back(x2-y2);
					t.push_back(x3-y3);
					di.push_back(z1-y1);
					di.push_back(z2-y2);
					di.push_back(z3-y3);
					std::vector<float> a;
					a=crossProduct(t,di);
					d=a[0]*x1+a[1]*x2+a[2]*x3;
					a.push_back(d);
					std::map<Node*, Node*> visited;					
					visited[graph[i]]=graph[i]->Neighbours[j];
					// cout<<graph[i]->Neighbours[j]->Neighbours.size()<<"\n";

					cycle=(find_cycle(a,graph[i]->Neighbours[j],graph[i],visited));
					// cout<<"I am back\n";
					Node* next=graph[i];
					std::vector<Node*> cyc_vec;
					cyc_vec.push_back(graph[i]);
					if(cycle.size()!=0){
						while(visited[next]!=graph[i]){
							// cout<<"stuck";
							cyc_vec.push_back(visited[next]);
							next=visited[next];
						}
						v.push_back(cyc_vec);
					}
					// cout<<"i "<<i<<" j "<<j<<" k "<<k<<"\n";

				}
			}
		}
		return v;
	}

	void print_Graph(std::vector<Node*> given_graph){
		for(int i=0;i<given_graph.size();i++){
			// cout<<"("<<given_graph[i]->x<<","<<given_graph[i]->y<<","<<given_graph[i]->z<<")";	
			// cout<<"Neighbours ->"<<"\n";

			for(int j=0;j<given_graph[i]->Neighbours.size();j++){
				// cout<<"("<<given_graph[i]->Neighbours[j]->x<<","<<given_graph[i]->Neighbours[j]->y<<","<<given_graph[i]->Neighbours[j]->z<<")";	
			}
			cout<<"\n";
		}
	}


};
Graph g;
std::vector<Node*> V_2D;

/**
 * Setting the  OpenGL window for Orthographic Views.
 *
 */
void init2D(float r, float g, float b)
{
	glClearColor(r,g,b,0.0);  
	glMatrixMode (GL_PROJECTION);
	// gluOrtho2D (0.0, 200.0, 0.0, 150.0);
	gluOrtho2D(-640/2.0, 640/2.0, -480/2.0, 480/2.0);
}
/**
 * creates the Orthographic View of the given object in OpenGL window
 *
 */
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1.0, 2.0, 0.0);

	glBegin(GL_LINES);
	for(int i=0;i<V_2D.size();i++){
		for(int j=0;j<V_2D[i]->Neighbours.size();j++){
				// cout<<"("<<V_2D[i]->x<<","<<V_2D[i]->y<<","<<V_2D[i]->z<<")";
				// cout<<"("<<V_2D[i]->Neighbours[j]->x<<","<<V_2D[i]->Neighbours[j]->y<<","<<V_2D[i]->Neighbours[j]->z<<")"<<"\n";
				glVertex3f(V_2D[i]->x,V_2D[i]->y,V_2D[i]->z);
				glVertex3f(V_2D[i]->Neighbours[j]->x,V_2D[i]->Neighbours[j]->y,V_2D[i]->Neighbours[j]->z);
			}
	}
	glEnd();


	glFlush();
}
/**
 * Setting the  OpenGL window
 *
 */
void initGL() {
   glClearColor(0.0f, 0.0f, 0.0f, 1.0f); // Set background color to black and opaque
   glClearDepth(1.0f);                   // Set background depth to farthest
   glEnable(GL_DEPTH_TEST);   // Enable depth testing for z-culling
   glDepthFunc(GL_LEQUAL);    // Set the type of depth-test
   glShadeModel(GL_SMOOTH);   // Enable smooth shading
   glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);  // Nice perspective corrections
}
/**
 * Giving random color to each vertex of the object.
 *
 */
void Color3D(){
	for(int i=0;i<cyclesD.size();i++){
		std::vector<std::vector<float>>  vf;
		for(int j=0;j<cyclesD[i].size();j++){
			float r1,r2,r3;
			r1=	static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
			r2=	static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
			r3=	static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
			std::vector<float> v;
			v.push_back(r1);
			v.push_back(r2);
			v.push_back(r3);
			vf.push_back(v);
		}
		colorsRand.push_back(vf);
	}
}
/**
 * creates the 3D View of the given object in OpenGL window
 *
 */
void display3D() {
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // Clear color and depth buffers
   glPushMatrix(); 	// It is important to push the Matrix before calling 
			// glRotatef and glTranslatef
    glRotatef(rotX,1.0,0.0,0.0); // Rotate on x
    glRotatef(rotY,0.0,1.0,0.0); // Rotate on y
    glRotatef(rotZ,0.0,0.0,1.0); // Rotate on z
    glTranslatef(X, Y, Z); 	// Translates the screen left or right, 
			// up or down or zoom in zoom out  
   // glMatrixMode(GL_MODELVIEW);     // To operate on model-view matrix
 
   // Render a color-cube consisting of 6 quads with different colors
   // glLoadIdentity();                 // Reset the model-view matrix
   // glTranslatef(-3.0f, 0.0f, -12.0f);  // Move right and into the screen
   // glRotatef(0,0,1,0);   
   // glRotatef(0,1,0,0);   
   glScalef(0.03f,0.03f,0.03f);
   
	for(int i=0;i<cyclesD.size();i++){
		float r1,r2,r3;
		
		glBegin(GL_POLYGON);
		// glColor3f(1.0f, 0.0f, 1.0f);
		// glColor3f(1.0f, 0.0f, 1.0f);
		

		glColor3f(r1,r2,r3);
		for(int j=0;j<cyclesD[i].size();j++){
			// cout<<"("<<cyclesD[i][j]->x<<","<<cyclesD[i][j]->y<<","<<cyclesD[i][j]->z<<","<<")"<<"->";
			// cout<<"Bye\n"<<colorsRand[i].size()<<"\n";
			r1=colorsRand[i][j][0];
			r2=colorsRand[i][j][1];
			r3=colorsRand[i][j][2];

			glVertex3f(cyclesD[i][j]->x,cyclesD[i][j]->y,cyclesD[i][j]->z);
		}
		glEnd();
		// cout<<"\n";
	}
	// glRotatef(45, 0.0f, 1.0f, 0.0f);
	// glRotatef(45, 1.0f, 0.0f, 0.0f);
	
	glScalef(0.01,0.01, 0.01);
	//????
	glPopMatrix(); 		// Don't forget to pop the Matrix
	glutSwapBuffers();  // Swap the front and back frame buffers (double buffering)
}

void reshape(int w, int h) {  // GLsizei for non-negative integer
    glViewport (0, 0, (GLsizei) w, (GLsizei) h); // Set the viewport
    glMatrixMode (GL_PROJECTION); 	// Set the Matrix mode
    glLoadIdentity (); 
    gluPerspective(75, (GLfloat) w /(GLfloat) h , 0.10, 100.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt (rotLx, rotLy, 15.0 + rotLz, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0); 
}
/**
 * This function is used for the navigation keys
 *
 */
void keyboard (unsigned char key, int x, int y)
{
	switch (key) {   // x,X,y,Y,z,Z uses the glRotatef() function
	    case 'x': // Rotates screen on x axis 
	    rotX -= 0.5f;
	    break;
	    case 'X': // Opposite way 
	    rotX += 0.5f;
	    break;
	    case 'y': // Rotates screen on y axis
	    rotY -= 0.5f;
	    break;
	    case 'Y': // Opposite way
	    rotY += 0.5f; 
	    break; 
	    case 'z': // Rotates screen on z axis
	    rotZ -= 0.5f;
	    break;
	    case 'Z': // Opposite way
	    rotZ += 0.5f;
	    break;
	    // j,J,k,K,l,L uses the gluLookAt function for navigation
	    case 'j':
	    rotLx -= 0.2f; 
	    glMatrixMode(GL_MODELVIEW);
	    glLoadIdentity();
	    gluLookAt (rotLx, rotLy, 15.0 + rotLz, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	    break;
	    case 'J':
	    rotLx += 0.2f;
	    glMatrixMode(GL_MODELVIEW);
	    glLoadIdentity();
	    gluLookAt (rotLx, rotLy, 15.0 + rotLz, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	    break; 
	    case 'k':
	    rotLy -= 0.2f;
	    glMatrixMode(GL_MODELVIEW);
	    glLoadIdentity();
	    gluLookAt (rotLx, rotLy, 15.0 + rotLz, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	    break;
	    case 'K':
	    rotLy += 0.2f;
	    glMatrixMode(GL_MODELVIEW);
	    glLoadIdentity();
	    gluLookAt (rotLx, rotLy, 15.0 + rotLz, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	    break;
	    case 'l': 	// It has a special case when the rotLZ becomes 
			// less than -15 the screen is viewed from the opposite side
	    // therefore this if statement below does not allow rotLz be less than -15
	    if(rotLz + 14 >= 0)
	    rotLz -= 0.2f;           
	    glMatrixMode(GL_MODELVIEW);    
	    glLoadIdentity();  
	    gluLookAt (rotLx, rotLy, 15.0 + rotLz, 0.0, 0.0, 0.0, 0.0,1.0,0.0);
	    break;
	    case 'L':
	    rotLz += 0.2f;
	    glMatrixMode(GL_MODELVIEW);
	    glLoadIdentity();
	    gluLookAt (rotLx, rotLy, 15.0 + rotLz, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	    break;
	    case 'b': // Rotates on x axis by -90 degree
	    rotX -= 90.0f;
	    break;
	    case 'B': // Rotates on y axis by 90 degree
	    rotX += 90.0f; 
	    break;
	    case 'n': // Rotates on y axis by -90 degree
	    rotY -= 90.0f;
	    break;
	    case 'N': // Rotates on y axis by 90 degree
	    rotY += 90.0f;
	    break;
	    case 'm': // Rotates on z axis by -90 degree
	    rotZ -= 90.0f; 
	    break;
	    case 'M': // Rotates on z axis by 90 degree
	    rotZ += 90.0f;
	    break;
	    case 'o': // Default, resets the translations vies from starting view
	    case 'O': 
	    X = Y = 0.0f;
	    Z = 0.0f;
	    rotX = 0.0f;
	    rotY = 0.0f;
	    rotZ = 0.0f;
	    rotLx = 0.0f;
	    rotLy = 0.0f;
	    rotLz = 0.0f;
	    glMatrixMode(GL_MODELVIEW);
	    glLoadIdentity();
	    gluLookAt(rotLx, rotLy, 15.0f + rotLz, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f);  
	    break;
	}
	glutPostRedisplay(); // Redraw the scene
}

/**
 * called on special key pressed
 *
 */
void specialKey(int key, int x, int y) { 
	// The keys below are using the gluLookAt() function for navigation
	// Check which key is pressed
	switch(key) {
	    case GLUT_KEY_LEFT : // Rotate on x axis
	    X -= 0.1f;
	    break;
	    case GLUT_KEY_RIGHT : // Rotate on x axis (opposite)
	    X += 0.1f;
	    break;
	    case GLUT_KEY_UP : // Rotate on y axis 
	    Y += 0.1f;
	    break;
	    case GLUT_KEY_DOWN : // Rotate on y axis (opposite)
	    Y -= 0.1f;
	    break; 
	    case GLUT_KEY_PAGE_UP: // Rotate on z axis
	    Z -= 0.1f;
	    break;
	    case GLUT_KEY_PAGE_DOWN:// Rotate on z axis (opposite)
	    Z += 0.1f;
	    break;
	}
    glutPostRedisplay(); // Redraw the scene
}

/**
 * Main function which takes the input from the main File and create the Orthographic view or 3D View.
 */
int  main(int argc,char *argv[]){
 	/**
 	 * This part will mainly contains gui program and taking inputs
 	 */
 	string line;
	ifstream myfile (argv[1]);
	if (myfile.is_open())
	{ 
		getline(myfile,line);
		std::stringstream stream(line);
		int n;
		stream>>n;
		int i=0; 
			while ( i<n )
			{ 
			  getline (myfile,line);
			  std::stringstream stream(line);
			  float x,y,z;
			  stream >> x;
			  stream >> y;
			  stream >> z;
			  Node* n=new Node();
			  n->x=x;
			  n->y=y;
			  n->z=z;
			  g.All_Node.push_back(n);
			  i++;
			}
		int edges;
		getline (myfile,line);
		std::stringstream strea(line);
		strea>>edges;
		i=0;
		while(i<edges){
			getline (myfile,line);
			std::stringstream stream(line);
			int a,b;
			stream >> a;
			stream >> b;
			g.All_Node[a]->Neighbours.push_back(g.All_Node[b]);
			g.All_Node[b]->Neighbours.push_back(g.All_Node[a]);
			i++;
		}
		myfile.close();
	}	
	else cout << "Unable to open file"; 
	// V_2D=g.FrontView(g.All_Node);
	// V_2D=g.ProfileView(g.All_Node);
	g.print_Graph(g.All_Node);
	// cout<<"Color";
	cyclesD= g.getPlanes(g.All_Node);
	Color3D();
	//Important for debuging
	// for(int i=0;i<cyclesD.size();i++){
	// 	for(int j=0;j<cyclesD[i].size();j++){
	// 		cout<<"("<<cyclesD[i][j]->x<<","<<cyclesD[i][j]->y<<","<<cyclesD[i][j]->z<<","<<")"<<"->";
	// 	}
	// 	cout<<"\n";
	// }


	// V_2D=g.TopView(g.All_Node);
	// for(int i=0;i<V_2D.size();i++){
	// 	for(int j=0;j<V_2D[i]->Neighbours.size();j++){
	// 			cout<<"("<<V_2D[i]->x<<","<<V_2D[i]->y<<","<<V_2D[i]->z<<")";
	// 			cout<<"("<<V_2D[i]->Neighbours[j]->x<<","<<V_2D[i]->Neighbours[j]->y<<","<<V_2D[i]->Neighbours[j]->z<<")"<<"\n";
	// 		}
	// }
	// glutInit(&argc,argv);
	// glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
	// glutInitWindowSize (500, 500);
	// glutInitWindowPosition (100, 100);
	// glutCreateWindow ("ED_SOFTWARE");
	// init2D(0.0,0.0,0.0);
	// glutDisplayFunc(display);
	// glutMainLoop();
	// srand(time(NULL));
	// cout<< (float)((rand() %10) + 1);
	// srand(time(NULL));
	// cout<< (float)((rand() %10) + 1);
	char c;
	do{
		cout<<"3D or 2D Views";
		int ch;
		cin>>ch;
		switch(ch){
			case 1://3D
					glutInit(&argc, argv);            // Initialize GLUT
					glutInitDisplayMode(GLUT_DOUBLE); 
					glutInitWindowSize(640, 480);   // Set the window's initial width & height
					glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
					glutCreateWindow("ED_SOFTWARE_3D");          // Create window with the given title
					glutDisplayFunc(display3D);       // Register callback handler for window re-paint event
					glutReshapeFunc(reshape);       // Register callback handler for window re-size event	
					initGL();                       // Our own OpenGL initialization
				    glutKeyboardFunc(keyboard); // set window's key callback 
				    glutSpecialFunc(specialKey); // set window's to specialKey callback
					glutMainLoop();                 // Enter the infinite event-processing loop
					break;
			case 2: cout<<"which view Top ,Profile or Front(0,1,2)";
					int view;
					cin>>view;
					switch(view){
						case 0:	V_2D=g.TopView(g.All_Node);
								break;
						case 1:	V_2D=g.ProfileView(g.All_Node);
								break;
						case 2:	V_2D=g.FrontView(g.All_Node);
								break;
								

					}
					glutInit(&argc,argv);
					glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
					glutInitWindowSize (500, 500);
					glutInitWindowPosition (100, 100);
					glutCreateWindow ("ED_SOFTWARE");
					init2D(0.0,0.0,0.0);
					glutDisplayFunc(display);
					glutMainLoop();
					break;
		}
		cout<<"want to continue(y/n)\n";
		cin>>c;
	}while(c='y');
	//3D
	// glutInit(&argc, argv);            // Initialize GLUT
	// glutInitDisplayMode(GLUT_DOUBLE); 
	// glutInitWindowSize(640, 480);   // Set the window's initial width & height
	// glutInitWindowPosition(50, 50); // Position the window's initial top-left corner
	// glutCreateWindow("ED_SOFTWARE_3D");          // Create window with the given title
	// glutDisplayFunc(display3D);       // Register callback handler for window re-paint event
	// glutReshapeFunc(reshape);       // Register callback handler for window re-size event	
	// initGL();                       // Our own OpenGL initialization
 //    glutKeyboardFunc(keyboard); // set window's key callback 
 //    glutSpecialFunc(specialKey); // set window's to specialKey callback
	// glutMainLoop();                 // Enter the infinite event-processing loop
	return 0;
}
