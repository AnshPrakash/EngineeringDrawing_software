make to compile

run using:
output <filename>

commands for controlling 3D objects:

x,X - rotates on x axis 
y,Y - rotates on y axis 
z,Z - rotates on z axis 
left_key - translates to left (x axis) 
right_key - translates to right (x axis) 
up_key - translates up (y axis) 
down_key - translates down (y axis) 
page_up - translates on z axis (zoom in) 
page_down - translates on z axis (zoom out) 
j,J translates on x axis 
k,K translates on y axis 
l,L translates on z axis 
b,B rotates (+/-)90 degrees on x axis
n,N rotates (+/-)90 degrees on y axis
m,M rotates (+/-)90 degrees on z axis
o,O brings everything to default (starting coordinates)
